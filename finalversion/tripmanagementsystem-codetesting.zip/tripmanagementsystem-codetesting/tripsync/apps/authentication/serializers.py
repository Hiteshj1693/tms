from rest_framework import serializers
from authentication.models import BlacklistedToken

# class BlacklistedTokenSerializer(serializers.Serializer):
