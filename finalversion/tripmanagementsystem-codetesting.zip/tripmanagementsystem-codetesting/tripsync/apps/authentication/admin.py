from django.contrib import admin
# from apps.authentication.models import BlacklistedToken
# Register your models here.

# admin.site.register(BlacklistedToken)
